<?php
    // Cette page sert uniquement à se déconnecter
    include('includes/fonctions.php');
    deconnexion();
?>