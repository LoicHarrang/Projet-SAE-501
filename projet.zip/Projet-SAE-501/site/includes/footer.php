<footer class="footer">
    <div class="row mt-5">
        <div class="col-md-12 text-center">
            <span class="text-muted">
                Copyright ©<script>
                    document.write(new Date().getFullYear());
                </script> - All rights reserved 
                <a href="javascript:history.back()">Retour à la page précédente</a>
            </span>
        </div>

    </div>
</footer>

<!-- Bootstrap -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
<!-- Pour l'Animate On Scroll -->
<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
<script>
    AOS.init();
</script>
</body>

</html>